<template>
  <div>
    <div style="margin: 20px 40px">
      <div style="float: left;width: 35%;">
        <el-image class="imageArea"
            style=""
            :src="this.pictureUrl">
          <template #error>
            <div class="image-slot">
              <el-icon><Picture /></el-icon>
            </div>
          </template>
        </el-image>
        <div>
          <el-upload
              :action=pictureUrl
              :on-success="pictureUploadSuccess"
              :show-file-list="false"
              :on-change="handleChange"
              :file-list="fileList"
              :limit="1"
          >
            <el-button type="primary">点击上传商品图片</el-button>
          </el-upload>
          <el-button @click="getPicture">获取图片</el-button>
        </div>

      </div>
      <div style="float: right;width: 60%">
        <el-form :model="goodsForm" class="goodsForm">
          <el-form-item label="名称:" >
            <el-input v-model="goodsForm.gname"></el-input>
          </el-form-item>
          <el-form-item label="价格:" >
            <el-input v-model="goodsForm.gname"></el-input>
          </el-form-item>
          <el-form-item label="大小:" >
            <el-input v-model="goodsForm.gname"></el-input>
          </el-form-item>
          <el-form-item label="大小:" >
            <el-input v-model="goodsForm.gname"></el-input>
          </el-form-item>
          <el-form-item label="是否可议价:" >
            <el-select v-model="goodsForm.bargain" style="width: 120px">
              <el-option label="一口价" value="false" />
              <el-option label="可议价" value="true" />
            </el-select>
          </el-form-item>
          <el-form-item label="详情">
            <el-input v-model="goodsForm.introduction" type="textarea"></el-input>
          </el-form-item>
        </el-form>
        <el-input-number v-model="num" :min="1" />
        <div style="margin: 10px auto;">
          <el-button type="danger" plain size="large" @click="" disabled>立即购买</el-button>
          <el-button type="danger" size="large" @click="" disabled>
            <el-icon style="color: white"><ShoppingCart /></el-icon >&ensp;加入购物车
          </el-button>
        </div>
        <div style="margin: 10px auto;">
          <el-button type="primary" @click="saveGoods">确认添加</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ShoppingCart,Picture } from '@element-plus/icons-vue'
import request from "@/util/request";
export default {
  name: "AddGood",
  components: {
    ShoppingCart,Picture
  },
  data(){
    return {
      gid: this.$route.query.gid,
      num: 1,
      goodsForm: {},
      pictureUrl:"",
      baseURL:"http://localhost:9090/files/upload/",
      fileList:[]
    }
  },
  created() {
    this.pictureUrl = this.baseURL
  },
  methods: {
    saveGoods(){
      this.goodsForm.status=3
      request.post("/goods",this.goodsForm).then(res=>{
        console.log(res)
        this.addGoodsVisible = false;
        this.load();
      })
    },
    pictureUploadSuccess(res){
      console.log(res.token)
      this.goodsForm.picture = res.token
    },
    handleChange(file){
      this.fileList=[file]
    },
    getPicture(){
      this.pictureUrl = this.baseURL+this.goodsForm.picture
      console.log(this.goodsForm.picture)
    },
    updateImgPath(){
      console.log("picture:"+this.goodsForm.picture)
      request.put("/user",this.userForm).then(res=>{
        // console.log(res)
        if(res.code === '0'){
          this.$message({
            type:"success",
            message: "申请成功，请等待审核通过",
          });
          this.beMctVisible = false;
        }else{
          this.$message({
            type:"error",
            message: res.msg,
          })
        }
        this.load();
      })
    },
  }
}
</script>

<style scoped>
  .infoItem{
    margin-top: 0;
  }
  .goodsForm{
    width: 300px;
  }
  .image-slot{
    width: 400px;
    border: 1px solid;
    height: 300px;
  }
  .imageArea{
    width: 400px;
    height: 300px;
  }
</style>