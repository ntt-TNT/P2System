<template>
  <div class="AllOrder">
    <div class="opeBoard">
      <el-button type="primary" @click="load">刷新</el-button>
    </div>
    <div class="searchBoard">
      <el-input v-model="searchText" placeholder="输入商品名" style="width: 20%" clearable>
      </el-input>
      <el-button type="primary" style="margin: 0 5px"
                 @click="search">查询</el-button>
    </div>
    <div class="displayBoard">
      <el-table :data="formTable.tableData"
                border
                stripe
                style="width: 100%"
      >
        <el-table-column type="expand">
          <!--        修改为自定义组件，显示其他信息-->
          <template #default="props">
            <deliveryExpand v-bind:order="props.row" />
          </template>
        </el-table-column>
        <el-table-column
            prop="gname"
            label="商品" />
        <el-table-column
            prop="price"
            label="单价" />
        <el-table-column
            prop="number"
            label="数量" />
        <el-table-column
            prop="sum"
            label="实付款" />
        <el-table-column
            fixed="right"
            label="状态"
            class="fixedOpe"
            width="180px"
            column-key="filterStatus">
          <template #header="scope">
            <el-select
                v-model="statusSelect"
                slot="prepend"
                @change="selectChange"
            >
              <el-option label="全部" value="5"></el-option>
              <el-option label="待发货" value="0"></el-option>
              <el-option label="待收货" value="1"></el-option>
              <el-option label="已收货" value="2"></el-option>
              <el-option label="交易成功" value="3"></el-option>
              <el-option label="退货中" value="-1"></el-option>
              <el-option label="退货成功" value="-2"></el-option>
              <el-option label="退货失败" value="-3"></el-option>
            </el-select>
          </template>
          <template #default="scope">
            <span v-if="scope.row.status === 0" style="line-height: 32px">
              待发货
              <el-popconfirm title="确认取消？" @confirm="deleteGoods(scope.row.oid)">
                <template #reference>
                  <el-button text type="danger" class="button">取消订单</el-button>
                </template>
              </el-popconfirm>
            </span>
            <span v-if="scope.row.status === 1" style="line-height: 32px">
              待收货
              <el-popconfirm title="确认收货？" @confirm="receiveGoods(scope.row)">
                <template #reference>
                  <el-button text type="danger" class="button">收货</el-button>
                </template>
              </el-popconfirm>
            </span>
            <span v-if="scope.row.status === 2" style="line-height: 32px">
              已收货

            <el-button text type="primary" @click="review(scope.row)" class="button">评价</el-button>
              <el-popconfirm title="确认退货？" @confirm="returnGoods(scope.row)">
                <template #reference>
                  <el-button text type="danger" class="button">退货</el-button>
                </template>
              </el-popconfirm>
            </span>
            <span v-if="scope.row.status === 3" style="color: limegreen;line-height: 32px">
              交易成功
            </span>
            <span v-if="scope.row.status === -1" style="color: red">退货中</span>
            <span v-if="scope.row.status === -2" style="color: red">退货成功</span>
            <span v-if="scope.row.status === -3" style="color: red">退货失败</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!--    分页-->
    <div style="margin: 10px">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[5, 10, 20]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>

  </div>
</template>

<script>
import axios from "axios";
import deliveryExpand from "@/components/DeliveryExpand";
import {Delete} from "@element-plus/icons-vue";

export default {
  name: "AllOrders",
  components: {
    deliveryExpand,
    Delete
  },
  data(){
    return{
      statusSelect: "全部",
      searchText: "",
      currentPage: 1,
      pageSize: 5,
      total: 0,
      tableData : [],
      formTable: {
        tableData: this.tableData,
      },
    }
  },
  created() {
    this.load()
  },
  methods:{
    load(){
      let params={
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
        searchText: this.searchText,
        uid:window.localStorage.getItem("uid"),
        status: 5,
      }
      axios.get("http://localhost:9090/orders/user",{
        params: params
      })
          .then(res=>{
            console.log(res);
            this.total=res.data.data.total;
            this.tableData = res.data.data.records;
            console.log(this.tableData)
            this.formTable.tableData = this.tableData;
          })
    },
    search(){
      this.load();
    },

    handleSizeChange(val) {//改变每页的显示条数
      this.pageSize = val;
      this.load()
    },
    handleCurrentChange(val) {//改变页码
      this.currentPage=val
      this.load()
    },

    selectChange(data){
      if (data==5){
        this.formTable.tableData = this.tableData;
      }else{
        this.formTable.tableData = this.tableData.filter((item) =>
            item.status == data
        );
      }
    },
    deleteGoods(id){
      console.log(id);
      axios.delete("http://localhost:9090/orders/"+id).then(res=>{

        if(res.data.code === '0'){
          this.$message({
            type:"success",
            message: "取消订单成功",
          });
          this.load()
        }else {
          this.$message({
            type: "error",
            message: res.msg,
          })
        }
      })
    },
    receiveGoods(order){
      axios.put("http://localhost:9090/orders?status=2",order).then(res=>{

        if(res.data.code === '0'){
          this.$message({
            type:"success",
            message: "收货成功",
          });
          this.load()
        }else {
          this.$message({
            type: "error",
            message: res.msg,
          })
        }
      })
    },
    retuenGoods(order){
      axios.put("http://localhost:9090/orders?status=2",order).then(res=>{

        if(res.data.code === '0'){
          this.$message({
            type:"success",
            message: "收货成功",
          });
          this.load()
        }else {
          this.$message({
            type: "error",
            message: res.msg,
          })
        }
      })
    },
  }
}
</script>

<style scoped>
.AllOrder{
  margin: 10px;
}
.opeBoard{
  margin: 10px 0;
}
.searchBoard{
  margin: 10px 0;
}
.fixedOpe{
  width: 120px;
  text-align: center;
}
.el-dropdown-link {
  cursor: pointer;
  color: #409EFF;
}
.el-icon-arrow-down {
  font-size: 12px;
}

.button{
  float: right;
  margin-right: 20px;
}

</style>